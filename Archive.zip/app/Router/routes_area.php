<?php

$routes->get("/", "AreaController::index");


// $routes->post("updateProfile", "AreaController::updateProfile");
// $routes->post("getSchools", "AreaController::getSchools");

// $routes->get("changePassword", "AreaController::changePassword");
// $routes->post("updatePassword", "AreaController::updatePassword");

// //
// $routes->get("manageMyCourses", "AreaController::manageMyCourses");
// $routes->get("createCourse", "AreaController::createCourse");
// $routes->post("saveCourse", "AreaController::saveCourse");
// $routes->get("editCourse/(:num)", "AreaController::editCourse/$1");
// $routes->post("updateCourse", "AreaController::updateCourse");
// $routes->get("deleteCourse/(:num)", "AreaController::deleteCourse/$1");
// $routes->get("deleteCoverCourse/(:num)", "AreaController::deleteCoverCourse/$1");

// //
// $routes->get("manageUnits/(:num)", "AreaController::manageUnits/$1");
// $routes->get("createUnit/(:num)", "AreaController::createUnit/$1");
// $routes->post("saveUnit", "AreaController::saveUnit");
// $routes->get("editUnit/(:num)", "AreaController::editUnit/$1");
// $routes->post("updateUnit", "AreaController::updateUnit");
// $routes->get("deleteUnit/(:num)", "AreaController::deleteUnit/$1");
// $routes->get("deleteDocumentUnit/(:num)", "AreaController::deleteDocumentUnit/$1");

// //
// $routes->get("manageQuestions/(:num)", "AreaController::manageQuestions/$1");
// $routes->get("createQuestion/(:num)", "AreaController::createQuestion/$1");
// $routes->post("saveQuestion", "AreaController::saveQuestion");
// $routes->get("editQuestion/(:num)", "AreaController::editQuestion/$1");
// $routes->post("updateQuestion", "AreaController::updateQuestion");
// $routes->get("deleteQuestion/(:num)", "AreaController::deleteQuestion/$1");

// //
// $routes->get("registedCourse", "Courses::registedCourse");

// //
// $routes->get("listUsers", "AreaController::listUsers");
// $routes->get("createUser", "AreaController::createUser");
// $routes->post("submit-form-storeUser", "AreaController::storeUser");
// $routes->get("editUser/(:num)", "AreaController::singleUser/$1");
// $routes->post("updateUser", "AreaController::updateUser");
// $routes->get("deleteUser/(:num)", "AreaController::deleteUser/$1");

// $routes->get("manageAreaCourses", "AreaController::manageAreaCourses");
// $routes->get("getAreaCourses/(:num)", "AreaController::getAreaCourses/$1");
// $routes->get("getAreaCourses/(:num)/(:num)", "AreaController::getAreaCourses/$1/$2");
// $routes->get("Areapretest/(:num)", "AreaController::Areapretest/$1");
// $routes->get("Areaposttest/(:num)", "AreaController::Areaposttest/$1");
// $routes->get("editAreaCourses/(:num)", "AreaController::editAreaCourse/$1");
// $routes->post("updateAreaCourse", "AreaController::updateAreaCourse");
// $routes->get("deleteAreaCourses/(:num)", "AreaController::deleteAreaCourse/$1");
// $routes->get("upstatusCourse/(:num)", "AreaController::upstatusCourse/$1");

// $routes->get("confirmAreaCourse", "AreaController::confirmAreaCourses");
// $routes->get("infoArea", "AreaController::infoArea");