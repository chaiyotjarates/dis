<?php

$routes->get("/", "ObecController::index");