<!-- Content Header (Page header) -->
<div class="content-header">
    <div class="container-fluid">
    <div class="row mb-2">
        <div class="col-sm-6">
        <h1 class="m-0"><?=$title['1']?></h1> 
        </div><!-- /.col -->
        <div class="col-sm-6">
            <!-- Breadcrumb -->
            <?php echo view('template/breadcrumb'); ?>
            <!-- /.Breadcrumb -->
        <!-- <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">หน้าหลัก</a></li>
            <li class="breadcrumb-item active">Dashboard</li>
        </ol> -->
        </div><!-- /.col -->
    </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div> 
<!-- /.content-header -->