ALTER TABLE `my_table`
 ADD COLUMN `updated_by` SMALLINT unsigned AFTER `date_created`