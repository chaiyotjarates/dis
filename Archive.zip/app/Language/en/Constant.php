<?php

// ค่าคงที่
return [
    'webTitle_full'    => 'ระบบโรงเรียนที่มีอิสระในการบริหารจัดการ',
    'webTitle_short'      => 'โรงเรียนอิสระฯ',
    'webTitle_short_eng'      => 'DIS',
    'webVersion' => '1.0',
    'webLogo' => 'Logo_OBEC.png',
    'webLogoCycle' => 'logo_cycle.png',
    'webAuth_Sumnuk' => 'สำนักพัฒนานวัตกรรมการจัดการศึกษา',
    'webAuth_Obec' => 'สำนักงานคณะกรรมการการศึกษาขั้นพื้นฐาน',
    'webAuth_Obec_Short' => 'สพฐ.',
    'webAuth_Moe' => 'กระทรวงศึกษาธิการ',
    'webHome' => 'https://dis.obec.go.th/',
    'webkuru' => 'https://dis.obec.go.th/',
    'email' => 'kuru-obec@gomail.com',
    'phone' => '089-046-9997',
    'auth' => 'THAIEDU.AC',
];
